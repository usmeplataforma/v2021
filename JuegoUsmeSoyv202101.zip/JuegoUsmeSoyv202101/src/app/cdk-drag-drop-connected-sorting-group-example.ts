import {Component} from '@angular/core';
import {CdkDragDrop, moveItemInArray, transferArrayItem} from '@angular/cdk/drag-drop';
import { textSpanOverlap } from 'typescript';

import {ModalDismissReasons, NgbModal} from '@ng-bootstrap/ng-bootstrap';


/**
 * @title Drag&Drop connected sorting group
 */
@Component({
  selector: 'cdk-drag-drop-connected-sorting-group-example',
  templateUrl: 'cdk-drag-drop-connected-sorting-group-example.html',
  styleUrls: ['cdk-drag-drop-connected-sorting-group-example.css'],
})

// ng build

export class CdkDragDropConnectedSortingGroupExample {

  closeModal: string;

  ImagePath: string;

  datosOficios: any;
  datosTradiciones: any;
  datosLugares: any;
  datosCelebraciones: any;
  
  constructor(private modalService: NgbModal) {
    //image location
    this.ImagePath = '/assets/img/'
  }

  triggerModal(content: any) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((res) => {
      this.closeModal = `Closed with: ${res}`;
    }, (res) => {
      this.closeModal = `Dismissed ${this.getDismissReason(res)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  centro : string[] = ['1-Lugares,', '3-Celebraciones', '2-Tradiciones,', '4-Oficios'];
  // centro2 : string[] = ['2-Tradiciones,', '4-Oficios'];

  fichas = [
    'http://app.toolsincloud.net/usmesoy2/img/Oficios01.png',
    'http://app.toolsincloud.net/usmesoy2/img/Oficios02.png',
    'http://app.toolsincloud.net/usmesoy2/img/Oficios03.png',
    'http://app.toolsincloud.net/usmesoy2/img/Oficios04.png',
    'http://app.toolsincloud.net/usmesoy2/img/Tradiciones01.png',
    'http://app.toolsincloud.net/usmesoy2/img/Tradiciones02.png',
    'http://app.toolsincloud.net/usmesoy2/img/Tradiciones03.png',
    'http://app.toolsincloud.net/usmesoy2/img/Tradiciones04.png',
    'http://app.toolsincloud.net/usmesoy2/img/Lugares01.png',
    'http://app.toolsincloud.net/usmesoy2/img/Lugares02.png',
    'http://app.toolsincloud.net/usmesoy2/img/Lugares03.png',
    'http://app.toolsincloud.net/usmesoy2/img/Lugares04.png',
    'http://app.toolsincloud.net/usmesoy2/img/Celebraciones01.png',
    'http://app.toolsincloud.net/usmesoy2/img/Celebraciones02.png',
    'http://app.toolsincloud.net/usmesoy2/img/Celebraciones03.png',
    'http://app.toolsincloud.net/usmesoy2/img/Celebraciones04.png',
    
  ];

  lugares : string[] = [];

  tradiciones : string[] = [];

  celebraciones : string[] = [];

  oficios : string[] = [];

  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
      console.log('Tarjeta: ' + event.container.data);
    } else {
      transferArrayItem(event.previousContainer.data,
                        event.container.data,
                        event.previousIndex,
                        event.currentIndex);
      console.log('Tarjeta actual: ' + event.container.id + ":" + event.currentIndex + ":" + event.container.data);
    }
  }

  getDatosCajas(){
    // tomar los datos de las cajasH y colocar cada valor en uno de los 4 destinos
    var idTema = ["Oficios","Saberes","Territorio","Identidad"];
    var j = 0;
    console.log("Inicio");
    
        
        // datosOficios, datosIdentidad, datosTerritorio, datosSaberes
        // var laCaja = document.getElementById(idTema[j]);
        // var nombrecaja = idTema[j];
        // console.log(nombrecaja);
        this.datosOficios = this.getNombres(this.oficios);
        console.log("datosOficios:" + this.datosOficios);
        
          this.datosTradiciones = this.getNombres(this.tradiciones);
          console.log("datosTradiciones: "+this.datosTradiciones);
      
          this.datosLugares = this.getNombres(this.lugares);
          console.log("datosLugares: "+this.datosLugares);  
      
          this.datosCelebraciones = this.getNombres(this.celebraciones);
          console.log("datosCelebraciones: "+this.datosCelebraciones);   
          
          document.forms[0].submit();
    return false;
  }

  getNombres(Lista: string[]){
    var temp : any = "";
    var sep = "";
    Lista.forEach(value => {
      temp += sep + value.substring(value.lastIndexOf("img/")+4, value.length-4);
      sep = ", "
    });
    return temp;
  }
}


/**  Copyright 2020 Google LLC. All Rights Reserved.
    Use of this source code is governed by an MIT-style license that
    can be found in the LICENSE file at http://angular.io/license */