<?php
header("Content-type: text/xml");
echo '<?xml version="1.0" encoding="UTF-8"?>';
echo "\n";
// Include config file
require_once "config.php";

function TestFunction($s_value) {
  $regex = '/^\s*[+\-]?(?:\d+(?:\.\d*)?|\.\d+)\s*$/';
  return preg_match($regex, $s_value); 
}

// Attempt select query execution
$sql = "SELECT id, nombre, descripcion, inmaterial, material, tnatural, latlong, ubicacion, direccion, comollegar, imagen FROM recurso";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
          // <markers>
          //         <marker id="1" name="Billy Kwong" address="1/28 Macleay Street, Elizabeth Bay, NSW" lat="-33.869843" lng="-151.225769" type="restaurant" />
          // </markers>

          // <markers>
                // <marker id="4" name="nuevo recurso" address="en usme" lat="4.504382604503957" lng="-74.10822128720028" type="building" />
                // <marker id="5" name="654654" address="calle con carrera" lat="4.456464303585131" lng="-74.09689163632137" type="building" />
                // <marker id="6" name="un nuevo recurso" address="calle con carrera usme" lat="4.498221856248794" lng="-74.15559982723934" type="building" />
          // </markers> 

        echo "<markers>\n";
            while($row = mysqli_fetch_array($result)){
                //  split latlong
                // (4.488866548045596, -74.12847732968075)
                $latlong0 = str_replace("(", "", $row['latlong']);
                $latlong0 = str_replace(")", "", $latlong0);
                $latlong = explode(", ", $latlong0);
                // validar que la lat y long sean válidas
                if (TestFunction($latlong[0]) && TestFunction($latlong[1])) {
                // type  inmaterial, material, tnatural
                // concatenar los tipos
                $tipo = $row['inmaterial'] . " " . $row['material'] . " " .  $row['tnatural'];

                  echo "<marker " ;
                    echo 'id="' . $row['id'] . '" ';
                    echo 'name="' . $row['nombre'] . '" ';
                    echo 'address="' . $row['direccion'] . '" ';
                    echo 'descripcion="' . $row['descripcion'] . '" ';
                    echo 'ubicacion="' . $row['ubicacion'] . '" ';
                    echo 'comollegar="' . $row['comollegar'] . '" ';
                    echo 'imagen="' . $row['imagen'] . '" ';
                    echo 'lat="' . $latlong[0] . '" ';
                    echo 'lng="' . $latlong[1] . '" ';
                    echo 'tipo="' .$tipo . '" ';
                    echo 'type="' .'parimonio' . '" ';
                    echo "/>\n";
                }
            }
            echo "</markers>";                            
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "<p class='lead'><em>No hay recursos almacenados.</em></p>";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

// Close connection
mysqli_close($link);
?> 
