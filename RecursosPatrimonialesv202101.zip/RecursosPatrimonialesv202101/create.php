<?php
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$name = $address = $salary = $nombre = $descripcion = $inmaterial = $material = $natural = $ubicacion = $latlong = $direccion = $inmaterial = $comollegar = $imagenname = $imagen = $fecha = $usuario = "";
$name_err = $address_err = $salary_err = $nombre_err = $descripcion_err = $inmaterial_err = $material_err = $natural_err = $ubicacion_err = $latlong_err = $direccion_err = $comollegar_err = $imagenname_err = $imagen_err = $fecha_err = $usuario_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate name
    $input_nombre = trim($_POST["nombre"]);
    if(empty($input_nombre)){
        $nombre_err = "Please enter a nombre.";
    // } elseif(!filter_var($input_nombre, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
    //     $name_err = "Please enter a valid nombre.";
    } else {
        $nombre = $input_nombre;
    }

    // Validate descripcion
    $input_descripcion = trim($_POST["descripcion"]);
    if(empty($input_descripcion)){
        $descripcion_err = "Please enter an descripcion.";     
    } else{
        $descripcion = $input_descripcion;
    }

    // Validate tipo: Inmaterial, Material, Natural
    if(!empty($_POST["inmaterial"])){
        $input_inmaterial = trim($_POST["inmaterial"]);
        if(empty($input_inmaterial)){
            $inmaterial_err = "Please enter an inmaterial.";     
        } else{
            $inmaterial = $input_inmaterial;
        }
    }
    if(!empty($_POST["material"])){
        $input_material = trim($_POST["material"]);
        if(empty($input_material)){
            $material_err = "Please enter an material.";     
        } else{
            $material = $input_material;
        }
    }
    if(!empty($_POST["natural"])){
        $input_natural = trim($_POST["natural"]);
        if(empty($input_natural)){
            $natural_err = "Please enter an natural.";     
        } else{
            $natural = $input_natural;
        }
    }


    // Validate Ubicación
    $input_ubicacion = trim($_POST["ubicacion"]);
    if(empty($input_ubicacion)){
        $ubicacion_err = "Please enter an ubicacion.";     
    } else{
        $ubicacion = $input_ubicacion;
    }


    // Validate latlong
    $input_latlong = trim($_POST["latlong"]);
    if(empty($input_latlong)){
        $latlong_err = "Please enter an latlong.";     
    } else{
        $latlong = $input_latlong;
    }

    
    // Validate address
    $input_direccion = trim($_POST["direccion"]);
    if(empty($input_direccion)){
        $direccion_err = "Please enter an direccion.";     
    } else{
        $direccion = $input_direccion;
    }

    // Validate comollegar
    $input_comollegar = trim($_POST["comollegar"]);
    if(empty($input_comollegar)){
        $comollegar_err = "Please enter an comollegar.";     
    } else{
        $comollegar = $input_comollegar;
    }

    // Validate imagenname
    $input_imagenname = trim($_POST["imagenname"]);
    if(empty($input_imagenname)){
        $imagenname_err = "Please enter an imagenname.";     
    } else{
        $imagenname = $input_imagenname;
    }

    $input_usuario = trim($_POST["usuario"]);
    if(empty($input_usuario)){
        $usuario_err = "Please enter an usuario.";     
    } else{
        $usuario = $input_usuario;
    }

    $input_fecha = trim($_POST["fecha"]);
    if(empty($input_fecha)){
        $fecha_err = "Please enter an fecha.";     
    } else{
        $fecha = $input_fecha;
    }

    // Validate imagen    
    // $name = $_FILES['file']['name'];
    $target_dir = "upload/";
    $target_file = $target_dir . basename($_FILES["imagen"]["name"]);
  
    // Select file type
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    // Convert to base64 
    $image_base64 = base64_encode(file_get_contents($_FILES['imagen']['tmp_name']) );
    $imagen = 'data:image/'.$imageFileType.';base64,'.$image_base64;
    // Insert record


    // $input_imagen = trim($_POST["imagen"]);
    // if(empty($input_imagen)){
    //     $imagen_err = "Please enter an imagen.";     
    // } else{
    //     $imagen = $input_imagen;
    // }


    // // Check if image file is a actual image or fake image
    // if(isset($_POST["submit"])) {
    //     $target_dir = "uploads/";
    //     $target_file = $target_dir . basename($_FILES["imagen"]["name"]);
    //     $uploadOk = 1;
    //     $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    //     $check = getimagesize($_FILES["imagen"]["tmp_name"]);
    //     if($check !== false) {
    //         echo "File is an image - " . $check["mime"] . ".";
    //         $uploadOk = 1;
    //     } else {
    //         echo "File is not an image.";
    //         $uploadOk = 0;
    // }
    // }

    // // Validate fecha
    // $input_imagen = trim($_POST["imagen"]);
    // if(empty($input_imagen)){
    //     $imagen_err = "Please enter an imagen.";     
    // } else{
    //     $imagen = $input_imagen;
    // }

    // // Validate usuario
    // $input_imagen = trim($_POST["imagen"]);
    // if(empty($input_imagen)){
    //     $imagen_err = "Please enter an imagen.";     
    // } else{
    //     $imagen = $input_imagen;
    // }


    
    // // Validate salary
    // $input_salary = trim($_POST["salary"]);
    // if(empty($input_salary)){
    //     $salary_err = "Please enter the salary amount.";     
    // } elseif(!ctype_digit($input_salary)){
    //     $salary_err = "Please enter a positive integer value.";
    // } else{
    //     $salary = $input_salary;
    // }
    


    // Check input errors before inserting in database
    
    if(empty($nombre_err) && empty($direccion_err) && 
            empty($descripcion_err) && empty($inmaterial_err) && empty($material_err) && 
            empty($natural_err) && empty($ubicacion_err) && empty($latlong_err) && empty($usuario_err) && empty($fecha_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO recurso (nombre, descripcion, inmaterial, material, tnatural, ubicacion, latlong, direccion, comollegar, imagenname, usuario, fecha, imagen) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sssssssssssss", $param_nombre, $param_descripcion, $param_inmaterial, $param_material, $param_natural, $param_ubicacion, $param_latlong, $param_direccion, $param_comollegar, $param_imagenname, $param_usuario, $param_fecha, $param_imagen);
            
            // Set parameters
            $param_nombre = $nombre;
            $param_descripcion = $descripcion;
            $param_inmaterial = $inmaterial;
            $param_material = $material;
            $param_natural = $natural;
            $param_ubicacion = $ubicacion;
            $param_latlong = $latlong;
            $param_direccion = $direccion;
            $param_comollegar = $comollegar;
            $param_imagenname = $imagenname;
            $param_usuario = $usuario;
            $param_fecha = $fecha;
            $param_imagen = $imagen;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: index.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
            // Close statement
            mysqli_stmt_close($stmt);
        } else {
            echo "Something's wrong with the query: " . mysqli_error($link);
            $imagen_err = mysqli_error($link);
        }
         

    }
    
    // Close connection
    mysqli_close($link);
}
?>
 
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Crear Recurso Patrimonio</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        .wrapper{
            width: 500px;
            margin: 0 auto;
        }
    </style>
     <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 250px;
        width: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      /* html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      } */
    </style>
</head>
<body>
    
    <div id="datos"></div>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h2>Crear Recurso Patrimonial</h2>
                        <a href="index.php" class="btn btn-success pull-right">Regresar al Inicio</a>
                    </div>
                    <p>Por favor escriba la información del Recurso Patrimonial que va a guardar.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
                        <div class="form-group <?php echo (!empty($nombre_err)) ? 'has-error' : ''; ?>">
                            <label>Nombre del recurso</label>
                            <input type="text" name="nombre" class="form-control" value="<?php echo $nombre; ?>">
                            <span class="help-block"><?php echo $nombre_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($descripcion_err)) ? 'has-error' : ''; ?>">
                            <label>Descripción</label>
                            <textarea name="descripcion" class="form-control"><?php echo $descripcion; ?></textarea>
                            <span class="help-block"><?php echo $descripcion_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($tipo_err)) ? 'has-error' : ''; ?>">
                            <label>Tipo</label>
                            <input type="checkbox" name="inmaterial" id="inmaterial" class="form-control" <?php  echo ($inmaterial=='Inmaterial') ? 'checked' : '' ?> value="Inmaterial"><label for="inmaterial">Inmaterial</label>
                            <input type="checkbox" name="material" id="material" class="form-control" <?php echo ($material=='Material') ? 'checked' : '' ?>  value="Material"><label for="material">Material</label>
                            <input type="checkbox" name="natural" id="natural" class="form-control" <?php  echo ($natural=='Natural') ? 'checked' : '' ?>  value="Natural"><label for="natural">Natural</label>
                            <span class="help-block"><?php echo $inmaterial_err;?></span>
                            <span class="help-block"><?php echo $material_err;?></span>
                            <span class="help-block"><?php echo $natural_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($ubicacion_err)) ? 'has-error' : ''; ?>">
                            <label>Ubicación</label>
                            <select name="ubicacion">
                                <option <?php  ($ubicacion=='Rural') ? 'selected' : '' ?> value='Rural'>Rural</option>
                                <option <?php  ($ubicacion=='Urbano') ? 'selected' : '' ?> value='Urbano'>Urbano</option>
                            </select>
                            <span class="help-block"><?php echo $ubicacion_err;?></span>
                        </div>
                        <div id="map"></div>
                        <div class="form-group <?php echo (!empty($latlong_err)) ? 'has-error' : ''; ?>">
                            <label>Latitud, Longitud</label>
                            <input type=text name="latlong" id="latlong" class="form-control" value="<?php echo $latlong; ?>">
                            <span class="help-block"><?php echo $latlong_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($direccion_err)) ? 'has-error' : ''; ?>">
                            <label>Dirección</label>
                            <textarea name="direccion" class="form-control"><?php echo $direccion; ?></textarea>
                            <span class="help-block"><?php echo $direccion_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($comollegar_err)) ? 'has-error' : ''; ?>">
                            <label>¿Cómo llegar?</label>
                            <textarea name="comollegar" class="form-control"><?php echo $comollegar; ?></textarea>
                            <span class="help-block"><?php echo $comollegar_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($imagenname_err)) ? 'has-error' : ''; ?>">
                            <label>Nombre de la Imagen</label>
                            <textarea name="imagenname" class="form-control"><?php echo $imagenname; ?></textarea>
                            <span class="help-block"><?php echo $imagenname_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($imagen_err)) ? 'has-error' : ''; ?>">
                            <img name="preview" src="" height="200" alt="Image preview...">
                            <label>Imagen</label>
                            <input type="file" name="imagen" id="imagen" onchange="previewFile()">
                            <!-- <textarea name="imagen" class="form-control"><?php echo $imagen; ?></textarea> -->
                            <span class="help-block"><?php echo $imagen_err;?></span>
                        </div>                        
                        <div class="form-group <?php echo (!empty($usuario_err)) ? 'has-error' : ''; ?>">
                            <label>Usuario</label>
                            <input type="text" name="usuario" class="form-control" value="<?php echo $usuario; ?>">
                            <span class="help-block"><?php echo $usuario_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($fecha_err)) ? 'has-error' : ''; ?>">
                            <label>Fecha</label>
                            <input type="date" name="fecha" class="form-control" value="<?php echo $fecha; ?>">
                            <span class="help-block"><?php echo $fecha_err;?></span>
                        </div>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>

    <script>
        function previewFile() {
            var preview = document.querySelector('img[name=preview]');
            var file    = document.querySelector('input[type=file]').files[0];
            var reader  = new FileReader();

            reader.onloadend = function () {
                preview.src = reader.result;
            }

            if (file) {
                reader.readAsDataURL(file);
            } else {
                preview.src = "";
            }
        }

      var customLabel = {
        restaurant: {
          label: 'R'
        },
        bar: {
          label: 'B'
        }
      };
        // BOSA, (4.6134620765869485, -74.219650976058)
        function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          center: new google.maps.LatLng(4.47622859893815, -74.12977429822931),  // Usme
          zoom: 12
        });
        var infoWindow = new google.maps.InfoWindow;

          // Change this depending on the name of your PHP or XML file
          downloadUrl('https://storage.googleapis.com/mapsdevsite/json/mapmarkers2a.xml', function(data) {
            var xml = data.responseXML;
            var markers = xml.documentElement.getElementsByTagName('marker');
            Array.prototype.forEach.call(markers, function(markerElem) {
              var id = markerElem.getAttribute('id');
              var name = markerElem.getAttribute('name');
              var address = markerElem.getAttribute('address');
              var type = markerElem.getAttribute('type');
              var point = new google.maps.LatLng(
                  parseFloat(markerElem.getAttribute('lat')),
                  parseFloat(markerElem.getAttribute('lng')));

              var infowincontent = document.createElement('div');
              var strong = document.createElement('strong');
              strong.textContent = name
              infowincontent.appendChild(strong);
              infowincontent.appendChild(document.createElement('br'));

              var text = document.createElement('text');
              text.textContent = address
              infowincontent.appendChild(text);
              var icon = customLabel[type] || {};
              var marker = new google.maps.Marker({
                map: map,
                position: point,
                label: icon.label
              });
              marker.addListener('click', function() {
                infoWindow.setContent(infowincontent);
                infoWindow.open(map, marker);
              });
            });
          });

          // Configure the click listener.
        map.addListener('click', function(mapsMouseEvent) {
          // Close the current InfoWindow.
          infoWindow.close();

          // Create a new InfoWindow.
          infoWindow = new google.maps.InfoWindow({position: mapsMouseEvent.latLng});
          infoWindow.setContent(mapsMouseEvent.latLng.toString());
          infoWindow.open(map);
          let datoLatLong = document.getElementById('latlong');
          datoLatLong.value = mapsMouseEvent.latLng.toString();
        });
        }



      function downloadUrl(url, callback) {
        var request = window.ActiveXObject ?
            new ActiveXObject('Microsoft.XMLHTTP') :
            new XMLHttpRequest;

        request.onreadystatechange = function() {
          if (request.readyState == 4) {
            request.onreadystatechange = doNothing;
            callback(request, request.status);
          }
        };

        request.open('GET', url, true);
        request.send(null);
      }

      function doNothing() {}
    </script>
    <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAkYbZIfEwG3O-c9mR-AOZlKS5AuC05f0Q&callback=initMap">
    </script>

</body>
</html>