-- tabla de recursos patrimoniales
Drop table recurso;
CREATE TABLE recurso ( id INT NOT NULL PRIMARY KEY AUTO_INCREMENT, 
                      nombre VARCHAR(100) NOT NULL, 
                      descripcion VARCHAR(500) NOT NULL,
                      información VARCHAR(500) NULL,
                      inmaterial VARCHAR(20) NOT NULL, 
                      material VARCHAR(20) NOT NULL, 
                      tnatural VARCHAR(20) NOT NULL, 
                      ubicacion VARCHAR(20) NOT NULL, 
                      latlong VARCHAR(50) NOT NULL,                     
                      direccion VARCHAR(255) NULL, 
                      comollegar VARCHAR(255) NULL, 
                      imagenname  VARCHAR(255) NULL, 
                      imagen LONGBLOB NOT NULL, 
                      fecha VARCHAR(20) NULL, 
                      usuario varchar(50) NULL );
Drop table recurso;
CREATE TABLE juego ( id INT NOT NULL PRIMARY KEY AUTO_INCREMENT, 
                      grupo VARCHAR(100) NOT NULL, 
                      integrantes VARCHAR(200) NOT NULL, 
                      comentarios VARCHAR(500) NOT NULL, 
                      comentarioscat1 VARCHAR(300) NOT NULL, 
                      comentarioscat2 VARCHAR(300) NOT NULL, 
                      comentarioscat3 VARCHAR(300) NOT NULL, 
                      comentarioscat4 VARCHAR(300) NOT NULL, 
                      categoria1 VARCHAR(500) NOT NULL, 
                      categoria2 VARCHAR(500) NOT NULL, 
                      categoria3 VARCHAR(500) NOT NULL, 
                      categoria4 VARCHAR(500) NOT NULL, 
                      fecha VARCHAR(20) NULL, 
                      usuario varchar(50) NULL )


CREATE TABLE usuario ( id INT NOT NULL PRIMARY KEY AUTO_INCREMENT, 
                      nombre VARCHAR(100) NOT NULL, 
                      usuario VARCHAR(20) NOT NULL, 
                      clave VARCHAR(20) NOT NULL, 
                      tipo VARCHAR(20) NOT NULL, 
                      zona VARCHAR(100) NOT NULL, 
                      ciudad VARCHAR(100) NOT NULL, 
                      fecha VARCHAR(20) NULL, 
                      usuario varchar(50) NULL );