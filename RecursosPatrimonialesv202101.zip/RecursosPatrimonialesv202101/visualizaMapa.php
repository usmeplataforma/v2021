<?php

$whitelist = array(
    '127.0.0.1',
    '::1'
);

if(!in_array($_SERVER['REMOTE_ADDR'], $whitelist)){
    define('APIXML', 'http://app.toolsincloud.net/patrimonioucc/readAllXML.php');
}
else {
    define('APIXML', 'http://localhost/RecursosPatrimoniales01/readAllXML.php');
}

?>

<!DOCTYPE html >
  <head>

  <meta charset="UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <title>Mapa de Recursos Patrimoniales</title>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 80%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
    </style>
  </head>
<html>
  <body>
    <div id="map">      
    </div>
        <h2 class="pull-left">Consulta de Recursos Patrimoniales &nbsp;
        <a href="index.php" class="btn btn-success pull-right">Regresar a Recursos</a></h2>
    </div>
    <script>
      var customLabel = {
        tnatural: {
          label: 'N'
        },
        material: {
          label: 'M'
        },
        inmaterial: {
          label: 'I'
        },
        patrimonio: {
          label: 'P'
        }
      };

        function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
            //center: new google.maps.LatLng(-33.863276, 151.207977),
            center: new google.maps.LatLng(4.47622859893815, -74.12977429822931),  // Usme
          zoom: 12
        });
        var infoWindow = new google.maps.InfoWindow;

          // Change this depending on the name of your PHP or XML file
         //  downloadUrl('https://storage.googleapis.com/mapsdevsite/json/mapmarkers2.xml', function(data) {
        //downloadUrl('http://app.toolsincloud.net/patrimonioucc/readAllXML.php', function(data) {
        downloadUrl("<?php echo APIXML ?>", function(data) {
            var xml = data.responseXML;
            var markers = xml.documentElement.getElementsByTagName('marker');
            Array.prototype.forEach.call(markers, function(markerElem) {
              var id = markerElem.getAttribute('id');
              var name = markerElem.getAttribute('name');
              var descripcion = markerElem.getAttribute('descripcion');
              var ubicacion = markerElem.getAttribute('ubicacion');
              var comollegar = markerElem.getAttribute('comollegar');
              var imagen = markerElem.getAttribute('imagen');
              var tipo = markerElem.getAttribute('tipo');;
              var address = markerElem.getAttribute('address');
              var type = markerElem.getAttribute('type');

              //var point = markerElem.getAttribute('latLong');
            // (4.488866548045596, -74.12847732968075)
              var point = new google.maps.LatLng(
                  parseFloat(markerElem.getAttribute('lat')),
                  parseFloat(markerElem.getAttribute('lng')));

              var infowincontent = document.createElement('div');
              infowincontent.width = 250;
              var strong = document.createElement('strong');
              strong.textContent = name
              infowincontent.appendChild(strong);
              infowincontent.appendChild(document.createElement('br'));
              infowincontent.appendChild(document.createElement('hr'));

              // img
              var Oimagen = document.createElement('img');
              Oimagen.src = imagen;
              Oimagen.width = 150;
              infowincontent.appendChild(Oimagen);
              infowincontent.appendChild(document.createElement('hr'));

              // address
              var textAddress = document.createElement('text');
              textAddress.textContent = address
              infowincontent.appendChild(textAddress);
              infowincontent.appendChild(document.createElement('hr'));

              // tipo
              var textTipo = document.createElement('text');
              textTipo.textContent = tipo
              infowincontent.appendChild(textTipo);
              infowincontent.appendChild(document.createElement('hr'));

              // descripcion
              var textdescripcion = document.createElement('text');
              textdescripcion.textContent = descripcion
              infowincontent.appendChild(textdescripcion);
              infowincontent.appendChild(document.createElement('hr'));

              // ubicacion
              var textubicacion = document.createElement('text');
              textubicacion.textContent = ubicacion
              infowincontent.appendChild(textubicacion);
              infowincontent.appendChild(document.createElement('hr'));

              // comollegar
              var textcomollegar = document.createElement('text');
              textcomollegar.textContent = comollegar
              infowincontent.appendChild(textcomollegar);
              infowincontent.appendChild(document.createElement('hr'));

              // comollegar google maps
              var textcomollegarG = document.createElement('a');
              textcomollegarG.href = "https://www.google.com/maps/dir//" + parseFloat(markerElem.getAttribute('lat'))+','+parseFloat(markerElem.getAttribute('lng'));
              textcomollegarG.textContent = "¿Cómo llegar?";
              textcomollegarG.target="_blank";
              infowincontent.appendChild(textcomollegarG);
              infowincontent.appendChild(document.createElement('hr'));
              // https://www.google.com/maps/dir//4.8298729,-74.5507664


              var icon = customLabel[type] || {};
              var marker = new google.maps.Marker({
                map: map,
                position: point,
                label: icon.label
              });
              marker.addListener('click', function() {
                infoWindow.setContent(infowincontent);
                infoWindow.open(map, marker);
              });
            });
          });
        }



      function downloadUrl(url, callback) {
        var request = window.ActiveXObject ?
            new ActiveXObject('Microsoft.XMLHTTP') :
            new XMLHttpRequest;

        request.onreadystatechange = function() {
          if (request.readyState == 4) {
            request.onreadystatechange = doNothing;
            callback(request, request.status);
          }
        };

        request.open('GET', url, true);
        request.send(null);
      }

      function doNothing() {}
    </script>
    <script defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAkYbZIfEwG3O-c9mR-AOZlKS5AuC05f0Q&callback=initMap">
    </script>
  </body>
</html>