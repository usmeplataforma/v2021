<?php

$whitelist = array(
    '127.0.0.1',
    '::1'
);

if(!in_array($_SERVER['REMOTE_ADDR'], $whitelist)){
    define('APIXML', 'http://app.toolsincloud.net/patrimonioucc/readAllXML.php');
}
else {
    define('APIXML', 'http://localhost/RecursosPatrimoniales01/readAllXML.php');
}

// read query string Q=E means search only the data with error
$where = "";
if(isset($_GET["Q"]) && !empty($_GET["Q"]) && $_GET["Q"]=="E"){
  // Get hidden input value
  $where = " latlong";
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Patrimonio</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.js"></script>
    <style type="text/css">
        .wrapper{
            width: 650px;
            margin: 0 auto;
        }
        .page-header h2{
            margin-top: 0;
        }
        table tr td:last-child a{
            margin-right: 15px;
        }
    </style>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 250px;
        width: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      /* html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      } */
    </style>
    <script type="text/javascript">
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    </script>
</head>
<body>
     <div id="map"></div>
     <div id="datos"></div>
    <div class="wrapper">
        <div class="container-fluid">            
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header clearfix">
                        <h2 class="pull-left">Administración de Recursos Patrimoniales</h2>
                        <a href="visualizaMapa.php" class="btn btn-success pull-right">Ver Mapa &nbsp; | &nbsp;</a>
                    </div>
                          <!-- <a href="index.php?q=E" class="btn btn-success pull-right">Verificar Recurso  &nbsp; | &nbsp;</a> -->
                          <a href="create.php" class="btn btn-success pull-right">Adicionar Recurso</a>
                    <?php
                    // Include config file
                    require_once "config.php";
                    // Define variables and initialize with empty values
                    $id = $nombre = $descripcion = $inmaterial = $material = $natural = $ubicacion = $latlong = $direccion = $comollegar = "";
                    // Attempt select query execution
                    $sql = "SELECT id, nombre, descripcion, inmaterial, material, tnatural, latlong, ubicacion, direccion, comollegar, imagen FROM recurso";
                    if($result = mysqli_query($link, $sql)){
                        if(mysqli_num_rows($result) > 0){
                            echo "<table class='table table-bordered table-striped'>";
                                echo "<thead>";
                                    echo "<tr>";
                                        echo "<th>#</th>";
                                        echo "<th>Nombre</th>";
                                        echo "<th>Tipo</th>";
                                        echo "<th>Descripción</th>";
                                        // echo "<th>Imagen</th>";
                                        echo "<th>¿Cómo llegar?</th>";
                                        echo "<th>Acciones</th>";

                                    echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";
                                while($row = mysqli_fetch_array($result)){
                                    $id = $row['id'];
                                    $nombre = $row['nombre'];
                                    $descripcion = $row['descripcion'];
                                    $inmaterial = $row['inmaterial'];
                                    $material = $row['material'];
                                    $natural = $row['tnatural'];
                                    $ubicacion = $row['ubicacion'];
                                    $latlong = $row['latlong'];
                                    $direccion = $row['direccion'];
                                    $comollegar = $row['comollegar']; 

                                    // procesar latlong
                                    $latlong0 = str_replace("(", "", $row['latlong']);
                                    $latlong0 = str_replace(")", "", $latlong0);

                                    echo "<tr>";
                                        echo "<td>" . $row['id'] . "</td>";
                                        echo "<td>" . $row['nombre'] . "</td>";
                                        echo "<td>" . $row['inmaterial'] ."<br>". $row['material'] ."<br>". $row['tnatural'] ."</td>";
                                        echo "<td>" . $row['descripcion'] . "</td>";
                                        // echo "<td><img width='100px' src='" . $row['imagen'] . "'></td>";
                                        // comollegar google maps
                                        echo "<td><a href='https://www.google.com/maps/dir//".$latlong0."' target='_blank'>¿Cómo llegar?</a></td>";
                                        echo "<td>";
                                            // echo "<a href='read.php?id=". $row['id'] ."' title='View Record' data-toggle='tooltip'><span class='glyphicon glyphicon-eye-open'></span></a>";
                                            echo "<a href='update.php?id=". $row['id'] ."' title='Actualizar' data-toggle='tooltip'><span class='glyphicon glyphicon-pencil'></span></a>";
                                            // echo "<a href='delete.php?id=". $row['id'] ."' title='Delete Record' data-toggle='tooltip'><span class='glyphicon glyphicon-trash'></span></a>";
                                            echo "<a href='consulta.php?id=". $row['id'] ."' title='Consultar' data-toggle='tooltip'><span class='glyphicon glyphicon-eye-open'></span></a>";
                                            echo "<a href='borrar.php?id=". $row['id'] ."' title='Borrar' data-toggle='tooltip'><span class='glyphicon glyphicon-trash'></span></a>";
                                        echo "</td>";
                                    echo "</tr>";
                                }
                                echo "</tbody>";
                            echo "</table>";
                            // Free result set
                            mysqli_free_result($result);
                        } else{
                            echo "<p class='lead'><em>No hay recursos almacenados.</em></p>";
                        }
                    } else{
                        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                    }
 
                    // Close connection
                    mysqli_close($link);
                    ?> 
                </div>
            </div>        
        </div>
    </div>
    <script>
      var customLabel = {
        tnatural: {
          label: 'N'
        },
        material: {
          label: 'M'
        },
        inmaterial: {
          label: 'I'
        }
      };

        function initMap() {
            var map = new google.maps.Map(document.getElementById('map'), {
                center: new google.maps.LatLng(4.47622859893815, -74.12977429822931),  // Usme
              zoom: 12
            });
            var infoWindow = new google.maps.InfoWindow;

          // Change this depending on the name of your PHP or XML file
          // <markers>
          //   <marker id="4" name="nuevo recurso" address="en usme" lat="4.504382604503957" lng="-74.10822128720028" type="building"/>
          //   <marker id="5" name="654654" address="calle con carrera" lat="4.456464303585131" lng="-74.09689163632137" type="building"/>
          //   <marker id="6" name="un nuevo recurso" address="calle con carrera usme" lat="4.498221856248794" lng="-74.15559982723934" type="building"/>
          // </markers>
            downloadUrl("<?php echo APIXML ?>", function(data) {
            var xml = data.responseXML;
            var markers = xml.documentElement.getElementsByTagName('marker');
            Array.prototype.forEach.call(markers, function(markerElem){ 
            
              var id = markerElem.getAttribute('id');
              var descripcion = markerElem.getAttribute('descripcion');
              var ubicacion = markerElem.getAttribute('ubicacion');
              var comollegar = markerElem.getAttribute('comollegar');
              var imagen = "";        //markerElem.getAttribute('imagen');
              var tipo = markerElem.getAttribute('tipo');;
              var address = markerElem.getAttribute('address');
              var type = markerElem.getAttribute('type');

              //var point = markerElem.getAttribute('latLong');
            // (4.488866548045596, -74.12847732968075)
              var point = new google.maps.LatLng(
                  parseFloat(markerElem.getAttribute('lat')),
                  parseFloat(markerElem.getAttribute('lng')));

              var infowincontent = document.createElement('div');
              var strong = document.createElement('strong');
              strong.textContent = name
              infowincontent.appendChild(strong);
              infowincontent.appendChild(document.createElement('br'));
              infowincontent.appendChild(document.createElement('hr'));

              // img
              var Oimagen = document.createElement('img');
              Oimagen.src = imagen;
              Oimagen.width = 150;
              infowincontent.appendChild(Oimagen);
              infowincontent.appendChild(document.createElement('hr'));

              // address
              var textAddress = document.createElement('text');
              textAddress.textContent = address
              infowincontent.appendChild(textAddress);
              infowincontent.appendChild(document.createElement('hr'));

              // tipo
              var textTipo = document.createElement('text');
              textTipo.textContent = tipo
              infowincontent.appendChild(textTipo);
              infowincontent.appendChild(document.createElement('hr'));

              // descripcion
              var textdescripcion = document.createElement('text');
              textdescripcion.textContent = descripcion
              infowincontent.appendChild(textdescripcion);
              infowincontent.appendChild(document.createElement('hr'));

              // ubicacion
              var textubicacion = document.createElement('text');
              textubicacion.textContent = ubicacion
              infowincontent.appendChild(textubicacion);
              infowincontent.appendChild(document.createElement('hr'));

              // comollegar
              var textcomollegar = document.createElement('text');
              textcomollegar.textContent = comollegar
              infowincontent.appendChild(textcomollegar);
              infowincontent.appendChild(document.createElement('hr'));

              // comollegar google maps
              var textcomollegarG = document.createElement('a');
              textcomollegarG.href = "https://www.google.com/maps/dir//" + parseFloat(markerElem.getAttribute('lat'))+','+parseFloat(markerElem.getAttribute('lng'));
              textcomollegarG.textContent = "¿Cómo llegar?";
              textcomollegarG.target="_blank";
              infowincontent.appendChild(textcomollegarG);
              infowincontent.appendChild(document.createElement('hr'));
              // https://www.google.com/maps/dir//4.8298729,-74.5507664

              var icon = customLabel[type] || {};

              var marker = new google.maps.Marker({
                map: map,
                position: point,
                label: icon.label
              });
              marker.addListener('click', function() {
                infoWindow.setContent(infowincontent);
                infoWindow.open(map, marker);
              });
            
          });

          // Configure the click listener.
        map.addListener('click', function(mapsMouseEvent) {
          // Close the current InfoWindow.
          infoWindow.close();

          // Create a new InfoWindow.
          infoWindow = new google.maps.InfoWindow({position: mapsMouseEvent.latLng});
          infoWindow.setContent(mapsMouseEvent.latLng.toString());
          infoWindow.open(map);
          let datoLatLong = document.getElementById('datos');
          datoLatLong.innerHTML = mapsMouseEvent.latLng.toString();
        });
        })



      function downloadUrl(url, callback) {
        var request = window.ActiveXObject ?
            new ActiveXObject('Microsoft.XMLHTTP') :
            new XMLHttpRequest;

        request.onreadystatechange = function() {
          if (request.readyState == 4) {
            request.onreadystatechange = doNothing;
            callback(request, request.status);
          }
        };

        request.open('GET', url, true);
        request.send(null);
      }

        }

      function doNothing() {}
    </script>
    <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAkYbZIfEwG3O-c9mR-AOZlKS5AuC05f0Q&callback=initMap">
    </script>

</body>
</html>